 <footer class="foo">
            <div class="row">
                <div class="col-lg-12">
                    <p style="text-align:center; font-family: 'Monotype Corsiva'; font-size:17px;"><i class="material-icons" style="color: brown;"></i> <b >Online Documents Sharing </b>
                </div>
            </div>
   </footer>